

<?php $__env->startSection('title', 'Input Data'); ?>

<?php $__env->startSection('header-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/save-data')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-12 mt-2">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Input Data</h3>
                    <div class="card-tools">                        
                        
                        <button type="submit" class="btn btn-primary btn-sm"> 
                            <i class="fa fa-save"></i> Simpan
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <?php if(count($errors) > 0): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close closeAlert" data-dismiss="alert"></button> 
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                            <?php endif; ?>
                            <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block msgAlert">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger msgAlert">
                                    <?php echo e(session()->get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-12">
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <label for="noHp">Nomor HP / Telephone</label>
                                    <input type="text" name="noHp" class="form-control" autocomplete="off" required>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input type="text" name="nama" class="form-control" autocomplete="off">
                                </div>
                            </div>
                            <?php if(Auth::user()->typeuser === 'CS'): ?>
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group clearfix">
                                    <div class="icheck-primary d-inline" style="margin-right:25px;">
                                        <input type="checkbox" name="cbTelpStatus" id="cbTelpStatus">
                                        <label for="cbTelpStatus">Sudah di Telephone
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 tgltelp" style="display:none;">
                                <div class="form-group">
                                    <label for="tgltelp">Tanggal Telephone</label>
                                    <input type="date" name="tgltelp" id="tgltelp" class="form-control" autocomplete="off">
                                </div>
                            </div>
                            
                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <label for="comment">Comment</label>
                                    <input type="text" name="comment" class="form-control" autocomplete="off">
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    
                </div>
            </div>
        </div>
    </div>    
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-js'); ?>
<script>
    $(function(){
        // $('#kodebank').on('change', function(){
        //     var namaBank = document.getElementById("kodebank").options[document.getElementById("kodebank").selectedIndex].text;
        //     const myArray = namaBank.split("-");
        //     console.log(myArray[1]);
        //     $('#namabank').val(myArray[1]);
        // })
        var _telpStatus =     'N';
        $('#cbTelpStatus').on('change', function(){
            if(_telpStatus === 'N'){
                _telpStatus = 'Y';
                $('.tgltelp').show();
                document.getElementById("tgltelp").required = true;
            }else{
                _telpStatus = 'N';
                $('.tgltelp').hide();
                document.getElementById("tgltelp").required = false;
            }
                // alert(_ppnchecked)
            // if(_telpStatus === 'Y'){
            //     $('.tgltelp').show();
            // }else{
            //     $('.tgltelp').hide();
            // }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KERJA\Side Job\tele-marketing\resources\views/input-master.blade.php ENDPATH**/ ?>