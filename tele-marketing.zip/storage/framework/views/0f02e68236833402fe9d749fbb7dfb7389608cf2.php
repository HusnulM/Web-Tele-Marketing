

<?php $__env->startSection('title', 'Laporan Data Contact'); ?>

<?php $__env->startSection('header-content'); ?>
<!-- <div class="content-header">
    <div class="container-fluid" style="background-color:#fff">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h1>Data User</h1>
            </div>
            <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Blank Page</li>
            </ol>
            </div>
        </div>
    </div>
</div>   -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mt-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Laporan Data Contact</h3>
                <div class="card-tools">
                    <!-- <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button> -->
                    
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close closeAlert" data-dismiss="alert"></button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                        <?php endif; ?>
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block msgAlert">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                            <strong><?php echo e($message); ?></strong>
                        </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger msgAlert">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="strdate">Dari Tanggal</label>
                            <input type="date" name="strdate" id="strdate" class="form-control">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="enddate">Sampai Tanggal</label>
                            <input type="date" name="enddate" id="enddate" class="form-control">
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <button type="button" class="btn btn-primary pull-right" id="btn-search">
                            <i class="fa fa-search"></i> Tampilkan Data
                        </button>
                    </div>
                </div>                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-js'); ?>
<script>
    $(document).keypress(
        function(event){
        if (event.which == '13') {
            event.preventDefault();
        }

    });
    
    $(function(){
        $('#btn-search').on('click', function(){
            var _Strdate = $('#strdate').val();
            var _Enddate = $('#enddate').val();
            if(_Strdate == ''){
                _Strdate = 'null';
                // alert('Tanggal tidak boleh kosong');
            }
            
            if(_Enddate == ''){
                _Enddate = 'null';
            }
            window.location.href = base_url+'/laporan-view/'+_Strdate+'/'+_Enddate
            // alert(_Bankid + ' - ' + _Strdate + ' - ' + _Enddate);
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KERJA\Side Job\tele-marketing\resources\views/laporan-sel.blade.php ENDPATH**/ ?>