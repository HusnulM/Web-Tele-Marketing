

<?php $__env->startSection('title', 'Data Contact Belum di Telp'); ?>

<?php $__env->startSection('header-content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mt-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Data Contact Belum di Telp</h3>
                <div class="card-tools">
                    <!-- <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button> -->
                    
                    
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close closeAlert" data-dismiss="alert"></button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                        <?php endif; ?>
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block msgAlert">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                            <strong><?php echo e($message); ?></strong>
                        </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger msgAlert">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                    
                <div class="row">
                    <div class="table-responsive">
                        <table id="tbl-users" class="table table-bordered table-striped table-hover table-sm">
                            <thead>
                                <th>No.</th>
                                <th>No HP / Telephone</th>
                                <th>Nama</th>
                                <th>Status</th>
                                <th>Tanggal Telephone</th>
                                <th>Comment</th>
                                <th style="width:170px;"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataTelp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($d->no_telp); ?></td>
                                    <td><?php echo e($d->nama); ?></td>
                                    <td style="text-align:center;">
                                        <?php if($d->sudah_ditelp === 'Y'): ?>
                                            <span class="badge badge-success">YES</span>
                                        <?php else: ?>   
                                            <span class="badge badge-danger">NO</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($d->tgl_telp); ?></td>
                                    <td><?php echo e($d->comment); ?></td>
                                    <td style="text-align:center;">
                                        <a href="/delete-data/<?php echo e($d->id); ?>" class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i> HAPUS
                                        </a> 
                                        <a href="/detail-data/<?php echo e($d->id); ?>" class="btn btn-success btn-sm">
                                            <i class="fa fa-edit"></i> EDIT
                                        </a>                                         
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-js'); ?>
<script>
    $(function(){
        $('#tbl-users').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KERJA\Side Job\tele-marketing\resources\views/display-master.blade.php ENDPATH**/ ?>